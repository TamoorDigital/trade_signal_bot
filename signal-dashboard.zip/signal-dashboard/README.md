# SMC Signal Dashboard (MEXC Futures + Gemini cross-check)

Scans top-volume MEXC USDT-M futures pairs on 1h/15m/5m, scores each setup against
an 8-part SMC checklist, cross-checks with Gemini (independent JSON scoring, 3-key
failover), and — only if **both** scores clear `MIN_SCORE` — opens a tracked signal
with structure-based SL/TP (not a fixed 1:2/1:3).

Not financial advice — this is a scanning/tracking tool, not a guarantee of results.
Test with small size before trusting it.

## 1. Local setup

```bash
cd signal-dashboard
npm install
cp .env.example .env
# edit .env: set MIN_SCORE, GEMINI_API_KEY_1 (at least one key), etc.
npm start
```

Open `http://localhost:3000`, click **Start**. It will:
- scan immediately, then every `SCAN_INTERVAL_MS` (default 5 min)
- track open trades every `TRACK_INTERVAL_MS` (default 1 min)

## 2. Environment variables (`.env`)

| Var | Meaning |
|---|---|
| `MIN_SCORE` | Min score out of 88 (see weights below) required from **both** your engine and Gemini before a trade opens |
| `WATCHLIST_TOP_N` | Auto-pick this many top-volume USDT-M pairs from MEXC (default 10) |
| `WATCHLIST` | Optional fixed comma-list (e.g. `BTC_USDT,ETH_USDT`) — overrides top-N auto-pick |
| `SCAN_INTERVAL_MS` | Scan loop period (default 300000 = 5 min) |
| `TRACK_INTERVAL_MS` | Trade-tracking loop period (default 60000 = 1 min) |
| `GEMINI_API_KEY_1/2/3` | Up to 3 Gemini API keys, tried in order — if key 1 fails/rate-limits, key 2 is tried, then key 3 |
| `GEMINI_MODEL` | Default `gemini-2.0-flash` |
| `PORT` | Server port (Render sets this automatically) |

Scoring weights (total 88): HTF bias 1h = 20, EMA200 trend regime = 15, fresh 15m
POI (OB/FVG) = 18, 5m liquidity sweep = 12, 5m BOS = 12, 5m CHoCH/MSS = 4,
momentum+volume = 5, candle pattern = 2.

## 3. How a signal gets created

1. Every scan cycle, each watchlist symbol is scored (long and short both tried,
   stronger side kept).
2. If a symbol already has an **open** trade, it's skipped (duplicate guard).
3. If `our_score >= MIN_SCORE`, the raw 1h/15m/5m candles (trimmed to ~40 bars
   each, compact array format to save tokens) are sent to Gemini as JSON, asking
   it to score the same checklist independently.
4. A trade is only opened if Gemini also returns `valid: true` with
   `score >= MIN_SCORE` and the same direction.
5. SL is placed just beyond the swept liquidity level (the actual wick that
   triggered the sweep), not a fixed percentage. TP1/TP2/TP3 are the next real
   swing points on 5m/15m beyond entry. R:R shown is derived from those levels,
   not chosen upfront.

## 4. Trade lifecycle & stats

Each open trade tracks `hits.tp1/tp2/tp3`. Every tracking cycle:
- TP3 hit → closed as **win**
- SL hit with no TP hit → closed as **loss**
- SL hit after TP1 and/or TP2 already hit → closed as **partial**

Win rate = (wins + partials) / total closed trades, shown on the dashboard along
with total trades, wins, losses, and currently open count.

## 5. Deploying to Render (free tier)

You chose the free web-service tier. Two things to know going in:

- **Storage**: trades are kept in `data/trades.json` on local disk. Render's free
  tier has an **ephemeral filesystem** — on redeploy (or periodic restarts) this
  file resets, so trade history/win-rate can be lost. Fine for testing; if you
  want it to survive restarts, add a paid Render Disk mounted at `/opt/render/project/src/data`
  later, or move `store.js` to an external DB — no other code changes needed.
- **Sleep**: free web services can sleep after ~15 min of no HTTP traffic, which
  pauses the scan/track loops too. A free uptime-pinger (e.g. UptimeRobot hitting
  `/api/status` every 5–10 min) keeps it awake. This is a known limitation of the
  free tier, not a bug in the app.

### Steps

1. Push this folder to a GitHub repo.
2. On [render.com](https://render.com) → **New +** → **Web Service** → connect the repo.
3. Settings:
   - **Environment**: Node
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Instance Type**: Free
4. Add environment variables (Render dashboard → Environment tab) — same keys as
   `.env.example`: `MIN_SCORE`, `WATCHLIST_TOP_N`, `GEMINI_API_KEY_1` (at least one),
   `GEMINI_MODEL`, `SCAN_INTERVAL_MS`, `TRACK_INTERVAL_MS`. Don't set `PORT` — Render
   injects it.
5. Deploy. Once live, open the Render URL, click **Start**.
6. (Optional) Set up UptimeRobot (or similar) to ping `https://<your-app>.onrender.com/api/status`
   every 5 minutes so the free instance doesn't sleep mid-scan.

## 6. File map

```
server.js            Express app + API routes
lib/mexcClient.js     MEXC futures klines + top-volume watchlist
lib/indicators.js      EMA/RSI/swing-point/FVG math
lib/scoring.js          8-criteria weighted scorer (long + short)
lib/geminiClient.js     Gemini prompt + 3-key failover
lib/signalEngine.js    Structure-based SL/TP builder
lib/store.js             JSON-file trade persistence + stats
lib/tracker.js           1-min price-vs-SL/TP loop
lib/scheduler.js       Start/stop + 5-min scan loop, duplicate guard
public/                Dashboard (start/stop, live table, stats, log)
```
